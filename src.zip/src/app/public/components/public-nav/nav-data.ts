export const navbarData = [
    {
        routeLink: '/dashboard',
        label: 'Home'
    },
    {
        routeLink: '/jobs',
        label: 'All Jobs'
    },
    {
        routeLink: '/about',
        label: 'About'
    },
    // {
    //     routeLink: '/services',
    //     label: 'Services'
    // },
    // {
    //     routeLink: '/contact',
    //     label: 'Contact'
    // }
];
