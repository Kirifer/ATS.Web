import { Component } from '@angular/core';

@Component({
  selector: 'app-public-about',
  templateUrl: './public-about.component.html',
  styleUrl: './public-about.component.css'
})
export class PublicAboutComponent {

}
