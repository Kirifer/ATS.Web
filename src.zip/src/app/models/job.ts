export interface Job {
    jobTitle: string;
    jobLocation: string;
    jobSetting: string;
    jobDescription: string;
    jobPosted: string;
}
