export interface Candidate {
}
