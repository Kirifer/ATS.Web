import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-job-candidate-existing',
  templateUrl: './admin-job-candidate-existing.component.html',
  styleUrl: './admin-job-candidate-existing.component.css'
})
export class AdminJobCandidateExistingComponent {

}
