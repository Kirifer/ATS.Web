import { Component } from '@angular/core';
import { ChangeDetectionStrategy } from '@angular/core';


@Component({
  selector: 'app-jobposting',
  templateUrl: './jobposting.component.html',
  styleUrl: './jobposting.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class JobpostingComponent {
onSubmit() {
throw new Error('Method not implemented.');
}
jobForm: any;

}
