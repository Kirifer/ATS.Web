import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-job-role-existing',
  templateUrl: './admin-job-role-existing.component.html',
  styleUrl: './admin-job-role-existing.component.css'
})
export class AdminJobRoleExistingComponent {

}
